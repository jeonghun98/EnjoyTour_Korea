-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: enjoytrip
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `plan_attraction`
--

DROP TABLE IF EXISTS `plan_attraction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plan_attraction` (
  `plan_no` int NOT NULL,
  `content_id` int NOT NULL,
  KEY `plan_attraction_to_plan_plan_no_fk` (`plan_no`),
  KEY `plan_attraction_to_attraction_info_content_id_fk` (`content_id`),
  CONSTRAINT `plan_attraction_to_attraction_info_content_id_fk` FOREIGN KEY (`content_id`) REFERENCES `attraction_info` (`content_id`),
  CONSTRAINT `plan_attraction_to_plan_plan_no_fk` FOREIGN KEY (`plan_no`) REFERENCES `plan` (`plan_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plan_attraction`
--

LOCK TABLES `plan_attraction` WRITE;
/*!40000 ALTER TABLE `plan_attraction` DISABLE KEYS */;
INSERT INTO `plan_attraction` VALUES (5,2787408),(5,2815034),(5,2782782),(6,2787408),(6,2782782),(6,2815034),(7,2787408),(7,2815034),(7,2782782),(7,133532),(7,2825179),(7,2614727),(8,2784112),(8,126080),(8,2785275),(8,2636878),(8,2777936),(10,2742711),(10,2848033),(10,2849718),(10,2855261),(10,2855370),(11,2615718),(11,133608),(11,2623938),(11,2570576),(11,2840189),(11,2733014),(12,1954936),(12,132437),(12,2654632),(12,128981),(12,1985850),(12,2778411),(13,2833147),(13,2855133),(13,2848033),(13,2849718),(14,2847995),(14,2833185),(14,2664722),(14,2742711),(14,2822573),(15,126526),(15,2756476),(15,131656),(15,126753),(16,2742711),(16,2664722),(16,2833185),(16,2847995);
/*!40000 ALTER TABLE `plan_attraction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-26  5:52:11
